package com.capgemini.bank.service;

import com.capgemini.bank.bean.DemandDraft;

public interface IDemandDraftService {
	String addDemandDraftDetails (DemandDraft demandDraft);

	DemandDraft getDemandDraftDetails(String transaction_id);

	
	
}
