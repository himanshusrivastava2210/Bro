package com.capgemini.bank.service;

import java.awt.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;
import com.capgemini.bank.util.DBConnection;

public class DemandDraftService implements IDemandDraftService{
	IDemandDraftService IDemandDraftService;
	



	public static void validateDemandDraft(DemandDraft demandDraft) throws DemandDraftException {
		ArrayList<String> validationErrors = new ArrayList<String>();

		//Validating name
		if(!(isValidCustomerName(demandDraft.getCustomer_name()))) {
			validationErrors.add("\n Patient Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
	
		if(!(isValidPhoneNumber(demandDraft.getPhone_number()))){
            validationErrors.add("\n Age Should Be greater than zero and should be less than 100 \n");
        }
		//Validating Phone Number
		if(!(isValidInfavourof(demandDraft.getIn_favor_of()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
		if(!(isValidRemarks(demandDraft.getDd_description()))){
			validationErrors.add("\n Phone Number Should be in 10 digit \n");
		}
				
	
		if(!validationErrors.isEmpty())
			throw new DemandDraftException(validationErrors +"");
	}

	

	private static boolean isValidRemarks(String dd_description) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(dd_description);
		return nameMatcher.matches();
	}



	private static boolean isValidInfavourof(String in_favor_of) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(in_favor_of);
		return nameMatcher.matches();
	}

	private static boolean isValidCustomerName(String customer_name) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(customer_name);
		return nameMatcher.matches();
	}

	
	
	public static boolean isValidPhoneNumber(String phoneNumber){
		Pattern phonePattern=Pattern.compile("^[1-9]{1}[0-9]{10}$");
		Matcher phoneMatcher=phonePattern.matcher(phoneNumber);
		return phoneMatcher.matches();
		
	}
	
	public static boolean validatetransactionid(String transaction_id) {
		
		Pattern idPattern = Pattern.compile("[0-9]{1,4}");
		Matcher idMatcher = idPattern.matcher(transaction_id);
		
		if(idMatcher.matches())
			return true;
		else
			return false;		
	}

	

	@Override
	public String addDemandDraftDetails(DemandDraft demandDraft) {
		IDemandDraftService= new DemandDraftService();
		String Transaction_Id_Seq ;
		Transaction_Id_Seq = IDemandDraftService.addDemandDraftDetails(demandDraft);
		return Transaction_Id_Seq ;
	}



	@Override
	public DemandDraft getDemandDraftDetails(String transaction_id) {
		IDemandDraftService=new DemandDraftService();
		DemandDraft demandDraft=null;
		demandDraft=IDemandDraftService.getDemandDraftDetails(transaction_id);
		return demandDraft;

	
}
}
