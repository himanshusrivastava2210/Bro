package com.capgemini.bank.dao;

public interface QuerryMapper {
	
	public static final String VIEW_DEMAND_DRAFT_DETAILS_QUERY="SELECT customer_name,in_favor_of ,phone_number,date_of_transaction ,dd_amount ,dd_commission ,dd_description  FROM demand_draft WHERE transaction_id=?";
	public static final String INSERT_QUERY="INSERT INTO demand_draft VALUES(Transaction_Id_Seq .NEXTVAL,?,?,?,(select SYSDATE from DUAL),?,?,?)";
	public static final String TRANSACTION_ID_QUERY_SEQUENCE="SELECT Transaction_Id_Seq.CURRVAL FROM DUAL";

}
