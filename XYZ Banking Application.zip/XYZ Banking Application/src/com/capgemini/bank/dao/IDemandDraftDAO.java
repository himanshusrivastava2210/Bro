package com.capgemini.bank.dao;

import com.capgemini.bank.bean.DemandDraft;
import com.capgemini.bank.exception.DemandDraftException;

public interface IDemandDraftDAO  {

	String addDemandDraftDetails(DemandDraft demandDraft) throws DemandDraftException;

	DemandDraft getDemandDraftDetails(String transaction_Id) throws DemandDraftException;
}
