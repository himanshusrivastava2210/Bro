package com.cg.pizzaorder.junit;


import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.bean.VegToppings;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;


public class PizzaTest {
	//Creating the object of PizzaOrderDAO class
	//To run the test case for placeOrder() in PizzaOrderDAO class
	IPizzaOrderDAO ipd1;

	@Before
	public void setup() {
        ipd1=new PizzaOrderDAO();
        
	}
	@After
	public void delete() {
		
		ipd1=null;
	}
	@Test
	public void testaddPat() throws PizzaException
	{    Customer customer= new Customer();
	     customer.setAddress("Hyderabad"); //Enter data which u give in the database
	     customer.setCustName("Vivek");
	     customer.setPhone("9876543210");
	     PizzaOrder pizza= new PizzaOrder();
	     pizza.setToppings(VegToppings.Capsicum);
		Assert.assertNotNull(ipd1.placeOrder(customer, pizza));
	}
	//To run the test case for getAllDetails() in PizzaOrderDAO class
	@Test
	public void testgetPat() throws PizzaException
	{   
		Assert.assertNotNull(ipd1.displayOrder(2001));
		
	}
}
