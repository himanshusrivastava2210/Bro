package com.capgemini.service;

import java.util.List;

import ccom.capgemini.tcc.bean.*;

import com.capgemini.tcc.*;
import com.capgemini.exception.*;
import com.capgemini.exception.*;
import com.capgemini.exception.PatientsException;

import ccom.capgemini.tcc.bean.Patientbean;


public interface IPatientService {
	public String addPatientDetails(Patientbean patientbean) throws PatientsException;
	public Patientbean viewPatientDetails(String patientId) throws PatientsException;
	public List<Patientbean> retriveAll()throws PatientsException;
}
