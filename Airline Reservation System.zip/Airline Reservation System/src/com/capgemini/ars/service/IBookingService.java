package com.capgemini.ars.service;

import java.util.List;

import com.capgemini.ars.dto.Booking;
import com.capgemini.ars.dto.Flight;
import com.capgemini.ars.exception.BookingException;



public interface IBookingService {
	public Booking addBooking(Booking booking) throws BookingException;
	public Booking updateBooking(int id, int passengers, String classType, int fare, int seats, 
			String creditCard, String srcCity, String deptCity) throws BookingException;
	List<Booking> getBookingList() throws BookingException;
	public Booking deleteBooking(int id) throws BookingException;
	public boolean validateDetails(Booking booking) throws BookingException;
	List<Flight> getFlightList() throws BookingException;
}
