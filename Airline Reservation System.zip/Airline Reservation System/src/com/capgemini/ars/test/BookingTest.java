package com.capgemini.ars.test;



import org.junit.Test;

import com.capgemini.ars.dao.BookingDaoImpl;
import com.capgemini.ars.dao.IBookingDao;
import com.capgemini.ars.dto.Booking;
import com.capgemini.ars.exception.BookingException;

import junit.framework.Assert;


public class BookingTest {

	@Test
	public void testInsert(){
		Booking s1= new Booking();
		s1.setBookingId(1);
		s1.setCustEmail("cap@capgemini.com");
		s1.setPassengers(3);
		s1.setClassType("Business");
		s1.setTotalFare(10000);
		s1.setSeatNo(6);
		s1.setCreditInfo("1234567890");
		s1.setSrcCity("Pune");
		s1.setDestCity("Kolkata");
		
		IBookingDao dao= new BookingDaoImpl();
		try {
			Booking s=dao.addBooking(s1);
			Assert.assertNotSame(0,s.getBookingId());
		} catch (BookingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}	
	@Test(expected=BookingException.class)
	public void testInsertForInvalidCourseCode() throws BookingException{
		Booking s1= new Booking();
		s1.setBookingId(1);
		s1.setCustEmail("cap@capgemini.com");
		s1.setPassengers(100);
		s1.setClassType("Business");
		s1.setTotalFare(100);
		s1.setSeatNo(6);
		s1.setCreditInfo("12345678908");
		s1.setSrcCity("Pune");
		s1.setDestCity("Kolkata");
		IBookingDao dao= new BookingDaoImpl();
		Booking s=dao.addBooking(s1);
	}
	
}
