package com.capgemini.ars.ui;


import java.util.List;
import java.util.Scanner;



//logger import
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.ars.dto.Booking;
import com.capgemini.ars.dto.Flight;
import com.capgemini.ars.exception.BookingException;
import com.capgemini.ars.service.BookingServiceImpl;
import com.capgemini.ars.service.IBookingService;

//logger import close


//import com.cg.mobile.validation.DataValidator;

public class Client {
	
	//Main Method
	
	public static void main(String[] args) {
		Logger logger=Logger.getRootLogger();
		PropertyConfigurator.configure("./resources/log4j.properties");
		Booking booking=new Booking();
	BookingServiceImpl service=new BookingServiceImpl();
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter choice : \n1. Insert Booking  \n2. Update Booking \n3. View Details of Booking "
			+ "\n4. Delete Booking");
	int ch=sc.nextInt();
	switch(ch){
	
	
	case 1: //case1:
	    {
	
		System.out.println("Enter Customer Email Id : ");
		String mailId= sc.next();
		System.out.println("Number of Passengers : ");
		int passengers=sc.nextInt();
		System.out.println("Class Type : Business/Economy");
		String classType= sc.next();
		String str1="Business",str2="Economy";
		if(classType.equalsIgnoreCase(str1)||classType.equalsIgnoreCase(str2))
		{
			
		}
		else
		{
			System.out.println("Invalid class");
			break;
		}
		System.out.println("Enter Seat Number : ");
		int seat=sc.nextInt();
		System.out.println("Enter Fare : ");
		int fare=sc.nextInt();
		System.out.println("Enter Credit Card Number : ");
		String credit= sc.next();
		System.out.println("Enter Source City : ");
		String src= sc.next();
		System.out.println("Enter Destination City : ");
		String des= sc.next();

		booking.setCustEmail(mailId);
		booking.setPassengers(passengers);
		booking.setClassType(classType);
		booking.setTotalFare(fare);
		booking.setSeatNo(seat);
		booking.setCreditInfo(credit);
		booking.setSrcCity(src);
		booking.setDestCity(des);
		
		
		try {
			
			Booking s1=service.addBooking(booking);
			logger.info("Booking added to DB..."+booking.getBookingId());
			System.out.println("Booking added to DB..."+booking.getBookingId());
			}
			
			 catch (BookingException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());}
		break;
	    } // case 1 closed
		
	      
	case 2:{
		
		System.out.println("Enter Booking Id : ");
		int id=sc.nextInt();
		System.out.println("Enter No Of Passengers : ");
		int passengers=sc.nextInt();
		System.out.println("Enter Class Type : ");
		String classType=sc.next();
		System.out.println("Enter Seats : ");
		int seats=sc.nextInt();
		System.out.println("Enter Fare : ");
		int fare=sc.nextInt();
		System.out.println("Enter Credid Card Number : ");
		String creditCard=sc.next();
		System.out.println("Enter Source City : ");
		String srcCity=sc.next();
		System.out.println("Enter Destination City : ");
		String deptCity=sc.next();
		
		try {
			Booking s1=service.updateBooking(id, passengers, classType, fare, seats, creditCard, srcCity, deptCity);
			if(s1.getBookingId()!=0)
				{
				logger.info("Booking updated ");
				System.out.println("Booking updated ");
				}
			else{
				logger.error("Booking not found..!!!");
				System.out.println("Booking not found..!!!");
		}} catch (BookingException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		
		break;
	}//case 2 closed
	
	case 3:{
		try {
			List<Booking> list=service.getBookingList();	
		    
		    if(list.size()==0)
		    {
		    	logger.error("No Booking available...");
		    	System.out.println("No Booking available...");
		    }else{
		    	for(Booking s: list){
		    		System.out.println(s.getBookingId()+" "+s.getCustEmail()+" "+ s.getPassengers()+" "
		    	+s.getClassType()+" "+ s.getTotalFare()+" "+s.getSeatNo()+" "+s.getCreditInfo()+" "
		    				+s.getSrcCity()+" "+s.getDestCity());
		    	}
		    	
		    }
		    
		} catch (BookingException e) {
			logger.error(e.getMessage());
		System.out.println(e.getMessage());
		}
		break;
		
	}//case 3 closed
	
	case 4:{
		System.out.println("Enter Booking Id : ");
		int id=sc.nextInt();
		
		try {
			Booking s1=service.deleteBooking(id);
			if(s1.getBookingId()!=0)
			{
				logger.info("Booking with BookingId = "+s1.getBookingId() +"deleted ");
				System.out.println("Booking with BookingId = "+s1.getBookingId() +"deleted ");
			}
			else
			{
				logger.error("Booking not found..!!!");
				System.out.println("Booking not found..!!!");
			}
		} 
		catch (BookingException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
		break;
	}//case 4 closed
	
	case 5:{
		try {
			List<Flight> list=service.getFlightList();	
		    
		    if(list.size()==0)
		    {
		    	logger.error("No flights are available...");
		    	System.out.println("No flights are available");
		    }
		    else
		    {
		    	for(Flight f: list){
System.out.println(f.getFlightno()+" "+f.getAirline()+" "+f.getDepcity()+" "+f.getArrcity()+" "+f.getDepdate()+" "+
	f.getArrdate()+" "+f.getDeptime()+" "+f.getArrtime()+" "+f.getFirstSeats()+" "+f.getFirstSeatfare()
	+" "+f.getBussSeatsno()+" "+f.getBussSeatfareno());	    
		    	}
		    	
		    }
		    
		} catch (BookingException e) {
			logger.error(e.getMessage());
		System.out.println(e.getMessage());
		}
		break;
		
	}
	
	default:
		System.out.println("Enter correct choice");
	//default close
		
	}//switch closed
	
	
	}//main closed
	}//class closed
	

