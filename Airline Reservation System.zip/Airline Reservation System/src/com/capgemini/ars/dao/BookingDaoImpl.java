package com.capgemini.ars.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.ars.dto.Booking;
import com.capgemini.ars.dto.Flight;
import com.capgemini.ars.exception.BookingException;
import com.capgemini.ars.util.DatabaseConnection;



public class BookingDaoImpl implements IBookingDao {
	private static Logger logger= Logger.getLogger(BookingDaoImpl.class);
	Connection connection;
	public BookingDaoImpl() {
	connection= DatabaseConnection.getConnection();	
	}
	private int generateBookingId() throws BookingException{
			int id=0;
		try {
			Statement s= connection.createStatement();
			ResultSet rs= 
		s.executeQuery("select bookingId.nextval from dual");
		if(rs.next())
			id=rs.getInt(1);
		} catch (SQLException e) {
			throw new BookingException(e.getMessage());
		}
		return id;
	}
	
	
	
	@Override
	public Booking addBooking(Booking booking) throws BookingException {
		String sql="insert into BookingInfo"
				+ " (BOOKING_ID, CUST_EMAIL, NO_OF_PASSENGERS, CLASS_TYPE, TOTAL_FARE, "
				+ "SEAT_NUMBER,  CREDITCARDINFO,  SRC_CITY, DEST_CITY)"
				+ "  values (?,?,?,?,?,?,?,?,?)";		
		//
		try {
			int id =generateBookingId();
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, id);
			ps.setString(2, booking.getCustEmail());
			ps.setInt(3,booking.getPassengers());
			ps.setString(4, booking.getClassType());
			ps.setInt(5, booking.getTotalFare());
			ps.setInt(6, booking.getSeatNo());
			ps.setString(7, booking.getCreditInfo());
			ps.setString(8, booking.getSrcCity());
			ps.setString(9, booking.getDestCity());
			ps.executeUpdate();
			booking.setBookingId(id);
			
		}catch (SQLException e) {
			if(e.getErrorCode()==1){
				logger.error("Booking code already exists...");
			 throw new BookingException("Booking code Already exists..!!!");
			}
			else if(e.getErrorCode()==2291){
				logger.error("Invalid Booking code ..!!");
				throw new BookingException("Invalid Booking code..!!");
			}
			else{
				logger.error(e.getMessage());
				throw new BookingException(e.getMessage());
			}
		}
		return booking;
	}
	
	@Override
	public Booking updateBooking(int id, int passengers, String classType, int fare, int seats,String creditCard, String srcCity, String deptCity) throws BookingException {
		String sql="update BookingInfo set NO_OF_PASSENGERS = ?, CLASS_TYPE = ?, TOTAL_FARE = ?, "
				+ "SEAT_NUMBER = ?,  CREDITCARDINFO = ? ,  SRC_CITY = ? , DEST_CITY = ? where BOOKING_ID = ?";
		Booking booking= new Booking();
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ps.setInt(1, passengers);
			ps.setString(2, classType);
			ps.setInt(3, fare);
			ps.setInt(4, seats);
			ps.setString(5, creditCard);
			ps.setString(6, srcCity);
			ps.setString(7, deptCity);
			ps.setInt(8, id);
			int row= ps.executeUpdate();
			if(row==1)
				booking.setBookingId(id);
		} catch (SQLException e) {
			logger.error(e.getMessage());
				throw new BookingException(e.getMessage());
		}
		return booking;
	}
	
	
	
	@Override
	public List<Booking> getBookingList() throws BookingException {
		String sql="Select * from BookingInfo";
		List<Booking> BookingList= new ArrayList<Booking>();
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			while(rs.next()){
				int id= rs.getInt("BOOKING_ID");
				String mail=rs.getString("CUST_EMAIL");
				int passenger=rs.getInt("NO_OF_PASSENGERS");
				String classType=rs.getString("CLASS_TYPE");
				int fare=rs.getInt("TOTAL_FARE");
				int seat=rs.getInt("SEAT_NUMBER");
				String credit=rs.getString("CREDITCARDINFO");
				String src=rs.getString("SRC_CITY");
				String des=rs.getString("DEST_CITY");
				
				Booking booking= new Booking();
				booking.setBookingId(id);
				booking.setCustEmail(mail);
				booking.setPassengers(passenger);
				booking.setClassType(classType);
				booking.setTotalFare(fare);
				booking.setSeatNo(seat);
				booking.setCreditInfo(credit);
				booking.setSrcCity(src);
				booking.setDestCity(des);
				
				BookingList.add(booking);
			}
			rs.close();
			ps.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BookingException(e.getMessage());
		}
		return BookingList;
	}
	
	
	
	
	
	@Override
	public Booking deleteBooking(int id) throws BookingException {
		
		  String sql="delete from BookingInfo where BOOKING_ID = ?";
			
		  Booking booking=new Booking();
			try {
				PreparedStatement ps= connection.prepareStatement(sql);
				ps.setInt(1, id);
				int row= ps.executeUpdate();
				if(row==1)
					booking.setBookingId(id);
			} catch (SQLException e) {
				logger.error(e.getMessage());
				throw new BookingException(e.getMessage());}
			
		return booking;
	}
	
	@Override
	public List<Flight> getFlightList() throws BookingException {
		String sql="Select * from FlightInfo1";
		List<Flight> FlightList= new ArrayList<Flight>();
		Flight flight=new Flight();
		try {
			PreparedStatement ps= connection.prepareStatement(sql);
			ResultSet rs = ps.executeQuery();
			
			while(rs.next())
			{
				
				int id= rs.getInt("Flight_no");
				String airline=rs.getString("Airline");
				String depcity=rs.getString("Dep_city");
				String arrcity=rs.getString("Arr_city");
				Date depdate=rs.getDate("Dep_Date");
				Date arrdate=rs.getDate("Arr_Date");
				String deptime=rs.getString("Dep_time");
				String arrtime=rs.getString("Arr_time");
				int firstSeats=rs.getInt("First_Seats");
				int firstSeatsfare=rs.getInt("FirstSeats_Fare");
				int businessSeats=rs.getInt("Business_Seats");
				int businessSeatsfare=rs.getInt("BusuinessSeats_Fare");
				
				
				flight.setFlightno(id);
				flight.setAirline(airline);
				flight.setDepcity(depcity);
				flight.setArrcity(arrcity);
				flight.setDepdate(depdate);
				flight.setArrdate(arrdate);
				flight.setFirstSeats(firstSeats);
				flight.setFirstSeatfare(firstSeatsfare);
				flight.setBussSeatsno(businessSeats);
				flight.setBussSeatfareno(businessSeatsfare);
				
				
				
				FlightList.add(flight);
			}
			rs.close();
			ps.close();
		} catch (SQLException e) {
			logger.error(e.getMessage());
			throw new BookingException(e.getMessage());
		}
		return FlightList;
	
	
	}
	

}
