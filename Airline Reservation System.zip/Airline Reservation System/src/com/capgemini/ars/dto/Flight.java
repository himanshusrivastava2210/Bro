package com.capgemini.ars.dto;
import java.util.Date;

	public class Flight {
		
		private int flightno;
	    private String airline; 
		private String  depcity;
		private String arrcity;
		private Date depdate;
		private Date arrdate; 
		private String deptime;
	    private String arrtime;
		private int firstSeats;
		private int firstSeatfare;
		private int bussSeatsno;
		private int bussSeatfareno;
		
		public int getFlightno() {
			return flightno;
		}
		public void setFlightno(int flightno) {
			this.flightno = flightno;
		}
		public String getAirline() {
			return airline;
		}
		public void setAirline(String airline) {
			this.airline = airline;
		}
		public String getDepcity() {
			return depcity;
		}
		public void setDepcity(String depcity) {
			this.depcity = depcity;
		}
		public String getArrcity() {
			return arrcity;
		}
		public void setArrcity(String arrcity) {
			this.arrcity = arrcity;
		}
		public Date getDepdate() {
			return depdate;
		}
		public void setDepdate(Date depdate) {
			this.depdate = depdate;
		}
		public Date getArrdate() {
			return arrdate;
		}
		public void setArrdate(Date arrdate) {
			this.arrdate = arrdate;
		}
		public String getDeptime() {
			return deptime;
		}
		public void setDeptime(String deptime) {
			this.deptime = deptime;
		}
		public String getArrtime() {
			return arrtime;
		}
		public void setArrtime(String arrtime) {
			this.arrtime = arrtime;
		}
		public int getFirstSeats() {
			return firstSeats;
		}
		public void setFirstSeats(int firstSeats) {
			this.firstSeats = firstSeats;
		}
		public int getFirstSeatfare() {
			return firstSeatfare;
		}
		public void setFirstSeatfare(int firstSeatfare) {
			this.firstSeatfare = firstSeatfare;
		}
		public int getBussSeatsno() {
			return bussSeatsno;
		}
		public void setBussSeatsno(int bussSeatsno) {
			this.bussSeatsno = bussSeatsno;
		}
		public int getBussSeatfareno() {
			return bussSeatfareno;
		}
		public void setBussSeatfareno(int bussSeatfareno) {
			this.bussSeatfareno = bussSeatfareno;
		}
		
}


