package com.cg.pizzaorder.bean;

import com.cg.pizzaorder.ui.PizzaOrderMain;

public class PizzaOrder 
{
	private int orderInt;
	private int customerId;
	private double totalPrice;
	public int getOrderInt() {
		return orderInt;
	}
	public void setOrderInt(int orderInt) {
		this.orderInt = orderInt;
	}
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public PizzaOrder(int orderInt, int customerId, double totalPrice) {
		super();
		this.orderInt = orderInt;
		this.customerId = customerId;
		this.totalPrice = totalPrice;
	}
	public double getTotalPrice() {
		return totalPrice;
	}
	public void setTotalPrice(double totalPrice)
	{
		this.totalPrice = totalPrice;
		
	}
	
}
