package com.cg.pizzaorder.junit;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;
import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;


public class PizzaTest {
	//Creating the object of PizzaOrderDAO class
	IPizzaOrderDAO ipd1=new PizzaOrderDAO();
	//To run the test case for placeOrder() in PizzaOrderDAO class
	@Test
	public void testaddPat() throws PizzaException
	{
		Assert.assertEquals(111, ipd1.placeOrder(new Customer("Debjit","Mumbai","Phone"),new PizzaOrder(111,12000,450)));
	}
	//To run the test case for getAllDetails() in PizzaOrderDAO class
	@Test
	public void testgetPat() throws PizzaException
	{
		ipd1.placeOrder(new Customer("Debjit","Mumbai","Phone"),new PizzaOrder(111,12000,450));
		Assert.assertNotNull(111);
	}
}
