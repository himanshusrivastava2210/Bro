package com.cg.pizzaorder.ui;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.Scanner;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;

public class PizzaOrderMain 
{
	static Scanner sc=null;
	static Random rand=null;
	static Customer customer =null;
	static PizzaOrder pizzaorder=null;
	static double totalPrize;
	static IPizzaOrderService ips=null;
	public static void main(String[] args) throws PizzaException
	{
		sc=new Scanner(System.in);
		int choice;
		while(true)
		{
		System.out.println("1.Place Order");
		System.out.println("2.Display Order");
		System.out.println("3.Exit");
		System.out.println("Enter your Choice");
		choice=sc.nextInt();
		performOperation(choice);
		}
	}
	private static void performOperation(int choice) throws PizzaException 
	{
		switch(choice)
		{
		case 1:placeOrder(); break;
		case 2:viewOrder(); break;
		default:System.exit(0);
		}
	}
	//To View The Orders
	private static void viewOrder() throws PizzaException
	{
		Map<Integer,PizzaOrder> map1=ips.getAllDetails();
		Iterator<PizzaOrder> it1=map1.values().iterator();
		while(it1.hasNext())
		{
			PizzaOrder po=it1.next();
			System.out.println("Order Id:" +po.getOrderInt());
			System.out.println("Customer Id: " +po.getCustomerId());
			System.out.println("Price: " +po.getTotalPrice());
			System.out.println("----------------------------------------------------");
		}
		
	}
	//To Add The Details In the Map
	private static void placeOrder() throws PizzaException 
	{
		ips=new PizzaOrderService();
		System.out.println("The first name only and should contains only character");
		System.out.println("Enter the name of the Customer(:");
		String name=sc.next();
		if(ips.validName(name))
		{
		
		}
		else
		{
			boolean myResult=false;
			while(myResult==false)
			{
				System.out.println("Just Write The FirstName And it should contain only Characters and no spaces between them");
			System.out.println("Enter name again");
			String fname1=sc.next();
			boolean b=ips.validName(fname1);
			if(b==true)
			{
				myResult=true;
			}
			}
		}
		System.out.println("Enter customer address");
		String add=sc.next();
		System.out.println("The number should not greater than 10 digits and contains digits only");
		System.out.println("Enter customer phone Number");
		String pNum=sc.next();
		if(ips.validMobile(pNum))
		{
			
		}
		else
		{
			boolean myResult=false;
			while(myResult==false)
			{
			System.out.println("The Number should Contains only digit and not be greater than 10 digits");
			System.out.println("Enter the number again");
			String num1=sc.next();
			boolean b=ips.validMobile(num1);
			if(b==true)
			{
				myResult=true;
			}
			}
		}
		System.out.println("Choose the type of pizza among-");
		System.out.println("Capsicum\t\t\t\t\t\t\t\t Rs.30");
		System.out.println("Mushroom\t\t\t\t\t\t\t\t Rs.50");
		System.out.println("Jalapeno\t\t\t\t\t\t\t\t Rs.50");
		System.out.println("panner\t\t\t\t\t\t\t\t Rs.50");
		System.out.println("Enter type of pizza");
		 String type=sc.next();
		 if(ips.validType(type))
		 {
			 
		 }
		 else
		 {
				boolean myResult=false;
				while(myResult==false)
				{
				System.out.println("Choose type Between-Capsicum,Mushroom,Jalapeno,Paneer");
				System.out.println("Enter the type again");
				String type1=sc.next();
				boolean b=ips.validType(type1);
				if(b==true)
				{
					myResult=true;
				}
				}
		 }
		if(type.equalsIgnoreCase("capsicum"))
		{
			totalPrize=350+30;
		}
		if(type.equalsIgnoreCase("mushroom"))
				{
			totalPrize=350+50;
				}
		if(type.equalsIgnoreCase("jalapeno"))
		{
			totalPrize=350+70;
		}
		if(type.equalsIgnoreCase("panner"))
		{
			totalPrize=350+85;
		}
		System.out.println("Order Date:");
		DateTimeFormatter dtf=DateTimeFormatter.ofPattern("yyyy/MM/dd:hh:mm:ss");
		LocalDateTime ld=LocalDateTime.now();
		System.out.println(dtf.format(ld));
	    rand=new Random();
		int oId=rand.nextInt();
		int cId=rand.nextInt();
		customer =new Customer(name,add,pNum);
		pizzaorder =new PizzaOrder(oId,cId,totalPrize);
		
		int oidRe=ips.placeOrder(customer, pizzaorder);
		System.out.println("Pizza Order successfully placed with Order Id:" +oidRe);
	}
}
