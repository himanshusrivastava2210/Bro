package threeTwo;
import java.util.Scanner;
import java.util.TreeSet;


public class Positive {
String str1;
String str2;

public boolean getPositive(){
	
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter String");
    str1=sc.next();
    TreeSet<Character> ts1= new TreeSet<>();
    for(int i=0;i<str1.length();i++){
    char c= str1.charAt(i);
    
ts1.add(c);
   
    }
    StringBuilder ss= new StringBuilder();
    for(Character ch:ts1){
    ss.append(ch);}
    str2=ss.toString();
    if(str1.equals(str2)){
    	System.out.println("Positive String");
    return true;
    }
    else{
    	System.out.println("Negative String");
    return false;
    }
    }

	
	public static void main(String[] args) {
	 Positive pp= new Positive();	
	  pp.getPositive(); 

	}

}

