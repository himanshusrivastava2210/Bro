package threeOne;
import java.util.Scanner;


public class Demo {

	public static void main(String[] args) {
		
		
		
	
	
	System.out.println("Enter First String ");
	Scanner sc1= new Scanner(System.in);
	String obj1= sc1.next();
	System.out.println("Enter Second String");
	Scanner sc2= new Scanner(System.in);
	String obj2= sc2.next();
	
	System.out.println("Enter Choice 1.Concatination 2.Replace odd places by # 3.Remove Duplicate 4.Change odd character by Uppercase.");
	Scanner sc = new Scanner(System.in);
int ch = sc.nextInt();

	Concat cn=new Concat();
	ReplaceFunction rd= new ReplaceFunction();
	Duplicate dd=new Duplicate();
	Upper uu= new Upper();
	switch(ch){
	
	case 1: 
		
		cn.concat(obj1,obj2);
		
		break;
	case 2: 
		rd.replace(obj1);
		break;
	case 3: 
		dd.rdisplay(obj1);
		break;
	case 4:
		uu.replace(obj1);
		break;
		default : System.out.println("Invalid Choice");
		break;
	}

	}

}
