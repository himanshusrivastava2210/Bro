package com.cg.empservice;

import com.cg.empdao.Empdao;
import com.cg.empdao.IEmpdao;
import com.cg.exception.EmployeeException;
import com.cg.lab10.Employee;





public class EmpService implements  IEmpService {
	IEmpdao dao;
	public EmpService(){
		dao=new Empdao();
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	@Override
	public Employee addEmployee(Employee employee) throws EmployeeException {
		// TODO Auto-generated method stub
		return null;
	}



}
