package com.cg.lab10;

import java.util.Scanner;

import com.cg.empservice.EmpService;
import com.cg.empservice.IEmpService;
import com.cg.exception.EmployeeException;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Employee e=new Employee();
		IEmpService service=new EmpService();
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter empid");
		int empid=sc.nextInt();
		System.out.println("Enter name:");
		String name=sc.next();
		System.out.println("Enter salary:");
		int salary=sc.nextInt();
		System.out.println("Enter gender");
		String gender=sc.next();
	    System.out.println("enter insurancescheme");
		String insurancescheme=sc.next();
		
		e.setEmpid(empid);
		e.setName(name);
		e.setGender(gender);
		e.setSalary(salary);
		e.setInsurancescheme(insurancescheme);
		try{
			Employee e1=service.addEmployee(e);
			System.out.println("Employee added to the db..");
			
		}catch(EmployeeException e1){
			System.out.println(e1.getMessage());
		}
	}

}
