package com.cg.mobile.service;

import java.util.List;

import com.cg.mobile.dto.Mobiles;
import com.cg.mobile.dto.PurchaseDetails;
import com.cg.mobile.exception.MobileException;

public interface IMobileService {

	
	public PurchaseDetails addDetails(PurchaseDetails purchase) throws MobileException;
	public Mobiles updateDetails(int quantity, int mobileId) throws MobileException;
	public List<Mobiles> getMobileList() throws MobileException;
	public Mobiles deleteDetails(int mobileId) throws MobileException;
	public List<Mobiles> inBetween(int min, int max) throws MobileException;
	public boolean validateDetails(PurchaseDetails purchase) throws MobileException ;
	
}
