package com.cg.lab2;

public class PersonalDetail {
	
	public static void main(String[] args) {
		
		System.out.println("Personal Details:");
		System.out.println("---------------------");
		System.out.println("First name: Saurabh");
		System.out.println("Last name: Srivastava");
		System.out.println("Gender: M");
		System.out.println("Age: 22");
		System.out.println("Weight: 76.50");
	}
}
