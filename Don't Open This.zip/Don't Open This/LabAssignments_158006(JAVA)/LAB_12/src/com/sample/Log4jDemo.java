package com.sample;
import org.apache.log4j.ConsoleAppender;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

public class Log4jDemo {
     static Logger logger=Logger.getLogger(Log4jDemo.class);
     
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PropertyConfigurator.configure("log4j.properties");
		logger.info("This is my info  msg");
		logger.debug("This is my debug message");
		logger.error("This is my error message");
		logger.warn("This is my warn message");
		logger.fatal("This is my fatal message");
		
		System.out.println("messages logged to file :basic.log");
     
	}

}

