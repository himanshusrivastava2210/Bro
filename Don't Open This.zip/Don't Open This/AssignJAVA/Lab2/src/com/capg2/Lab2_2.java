package com.capg2;

public class Lab2_2 {
	public static void main(String[] args) {
		for(int i = 0; i < args.length; i++) {
			Integer n = new Integer(args[i]);
		
		if(n>0) {
			System.out.println("positive number");
		}
		else {
			System.out.println("negative number");
		}
		}
		}
}
