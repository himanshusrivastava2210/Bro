package com.capg;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Lab7_5 {
	public static void main(String args[]) {
		List<String> l1 = new ArrayList<String>();
		Scanner s = new Scanner(System.in);
		System.out.println("Enter no of elements");
		int n = s.nextInt();
		for (int i1 = 0; i1 < n; i1++) {
			l1.add((String) s.next());

		}
		Collections.sort(l1);
		for (String str : l1) {
			System.out.println(str);
		}

	}

}
