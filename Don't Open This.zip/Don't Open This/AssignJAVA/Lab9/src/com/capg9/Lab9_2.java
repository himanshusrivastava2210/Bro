package com.capg9;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

public class Lab9_2 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		File source = new File("D:/numbers.txt");
		Scanner sc;
		try {
			sc = new Scanner(source).useDelimiter(",");
			while (sc.hasNext()) {
				int num = sc.nextInt();
				if (num % 2 == 0) {
					System.out.println(num);
				}
			}
			sc.close();
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			System.out.println("File not found exception occured");
		}

	}

}
