package com.capg.ui;

import java.util.Random;
import java.util.Scanner;

import com.capg.service.Account;
import com.capg.service.AccountInheritance;
import com.capg.service.Person;

public class LAb5_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		Random rand = new Random();
		System.out.println("Enter Account Holder's Name");
		String name = sc.next();
		System.out.println("Enter Age");
		int age = sc.nextInt();
		System.out.println("Enter Balance");
		double balance = sc.nextDouble();
		
		Person p = new Person();
		p.setName(name);
		p.setAge(age);
		
		Account ac = new AccountInheritance();
		ac.setAccNo(rand.nextLong());
		ac.setBalance(balance);
		ac.setPer(p);
		ac.deposit(2000);
		ac.withDraw(1000);
		String account1 = p.getName();
		
		System.out.println("Account Number is :"+ac.getAccNo());
		System.out.println("Balance is"+ac.getBalance());
		System.out.println("Account Holder name is:"+ac.getPer().getName());
		System.out.println("Account Holder age is:"+ac.getPer().getAge());
		
		

	}

}
