package com.capg6_1;

public class Person {
	String name;

	float age;

	public Person(String name, float age)

	{

		this.name = name;

		this.age = age;

	}

	public Person(String string, String string2, String string3) {
		// TODO Auto-generated constructor stub
	}

	public String getName() {

		return name;

	}

	public void setName(String name) {

		this.name = name;

	}

	public float getAge() {

		return age;

	}

	public void setAge(float age) {

		this.age = age;

	}

	@Override

	public String toString() {

		return "Person [name=" + name + ", age=" + age + "]";

	}

	public String getFn() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getLn() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getGender() {
		// TODO Auto-generated method stub
		return null;
	}

}
