package com.capg11;

import java.util.Scanner;

public class Lab11_5 {
	public static void main(String[] args) {
		ILab11_5 lb = (x) -> {
			int fact = 1;
			for (int i = 1; i <= x; i++) {
				fact = fact * i;
			}
			return fact;
		};
		System.out.println("enter number");
		Scanner sc = new Scanner(System.in);
		int y = sc.nextInt();
		System.out.println("fact of " + y + " " + lb.factorial(y));
	}
}
