package com.capg11;
@FunctionalInterface
public interface ILab11_3 {
	
	boolean valid(String user,String pswrd);

	}

