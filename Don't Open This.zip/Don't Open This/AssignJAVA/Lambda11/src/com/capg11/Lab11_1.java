package com.capg11;

public class Lab11_1 {
	public static void main(String[] args) {
		ILab11_1 res = (x, y) -> Math.pow(x, y);
		double result = res.power(10, 2);
		System.out.println(result);
	}
}
