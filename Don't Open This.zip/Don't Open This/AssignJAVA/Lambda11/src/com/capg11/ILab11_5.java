package com.capg11;

public interface ILab11_5 {
public int factorial(int x);
}
