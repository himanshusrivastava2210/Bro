package com.capg11;

public interface ILab11_4 {
	
	public abstract Lab11_4_1 getLamdaImp11_11_4(int id,String name,int age);

	}


