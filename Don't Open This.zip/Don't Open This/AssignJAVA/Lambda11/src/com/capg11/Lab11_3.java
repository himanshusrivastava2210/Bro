package com.capg11;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Lab11_3 {
	public static void main(String[] args) {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("enter username and password ");
		String username = "Akhila";
		String password = "shruthi";
		try {
			String username1 = br.readLine();
			String password1 = br.readLine();
			ILab11_3 v = (user, pswrd) -> {
				if (user.equalsIgnoreCase(username) && pswrd.equalsIgnoreCase(password))
					return true;
				else
					return false;
			};
			if (v.valid(username1, password1))
				System.out.println("valid details");
			else
				System.out.println("invalid details");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
