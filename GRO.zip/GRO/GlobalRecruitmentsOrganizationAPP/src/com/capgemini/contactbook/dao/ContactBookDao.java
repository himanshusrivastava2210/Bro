package com.capgemini.contactbook.dao;

import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;

public interface ContactBookDao {
	public static int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		// TODO Auto-generated method stub
		return 0;
	}

	public static EnquiryBean getEnquiryDetails(int enquiryID) {
		// TODO Auto-generated method stub
		return null;
	}
}
