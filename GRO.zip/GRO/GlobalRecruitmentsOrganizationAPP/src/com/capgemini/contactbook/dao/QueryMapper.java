package com.capgemini.contactbook.dao;

public interface QueryMapper {
	
		public static final String INSERT_QUERY="INSERT INTO enquiry VALUES(enquiries.NEXTVAL,?,?,?,?, (select SYSDATE from DUAL))";
		public static final String ENQUIRYID_QUERY_SEQUENCE="SELECT enquiries.CURRVAL FROM DUAL";
}
