package com.capgemini.contactbook.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.contactbook.dao.ContactBookDao;
import com.capgemini.contactbook.dao.ContactBookDaoImpl;
import com.capgemini.contactbook.exception.ContactBookException;
import com.igate.contactbook.bean.EnquiryBean;




public class ContactBookServiceImpl implements ContactBookService {

	private ContactBookDao contactBookDao;

	public ContactBookServiceImpl() 
	{
		contactBookDao = new ContactBookDaoImpl();
	}

	@Override
	public int addEnquiry(EnquiryBean enqry) throws ContactBookException {
		contactBookDao= new ContactBookDaoImpl();
		int enquiries;
		enquiries= ContactBookDao.addEnquiry(enqry);
		return enquiries;
	}

	@Override
	public EnquiryBean getEnquiryDetails(int enquiryID) throws ContactBookException {
	
		return ContactBookDao.getEnquiryDetails( enquiryID );
	}

	@Override
	public boolean isValidEnquiry(EnquiryBean enqry) throws ContactBookException 
	{
		List<String> validationErrors = new ArrayList<String>();

		
		//Validating contact Number
				if(!(isValidContactNo(enqry.getContactNo()))){
					validationErrors.add("\n Contact Number Should be in 10 digit \n");
				}
				
		//Validating first name
		if(!(isValidfName(enqry.getfName()))) {
			validationErrors.add("\n   first Name Should Be In Alphabets and minimum 3 characters long ! \n");
		}
		
		//Validating last name
				if(!(isValidlName(enqry.getlName()))) {
					validationErrors.add("\n   first Name Should Be In Alphabets and minimum 3 characters long ! \n");
				}
		
		
				//Validating pLocation
				if(!(isValidpLocation(enqry.getpLocation()))) {
					validationErrors.add("\n   pLocation Should Be In Alphabets and minimum 3 characters long ! \n");
				}
				
				//Validating pDomain
				if(!(isValidpDomain(enqry.getpDomain()))) {
					validationErrors.add("\n   pDomainShould Be In Alphabets and minimum 3 characters long ! \n");
				}
	
		if(!validationErrors.isEmpty())
			throw new ContactBookException(validationErrors +"");
		return false;
	}

	public boolean isValidpDomain(String getpDomain) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getpDomain);
		return nameMatcher.matches();
	}

	public boolean isValidpLocation(String getpLocation) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getpLocation);
		return nameMatcher.matches();
	}

	public boolean isValidlName(String getlName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getlName);
		return nameMatcher.matches();
	}

	public boolean isValidfName(String getfName) {
		Pattern namePattern=Pattern.compile("^[A-Za-z]{3,}$");
		Matcher nameMatcher=namePattern.matcher(getfName);
		return nameMatcher.matches();
	}

	public boolean isValidContactNo(String contactNo) {
		Pattern contactPattern=Pattern.compile("^[1-9]{1}[0-9]{9}$");
		Matcher contactMatcher=contactPattern.matcher(contactNo);
		return contactMatcher.matches();
	}
	
}
